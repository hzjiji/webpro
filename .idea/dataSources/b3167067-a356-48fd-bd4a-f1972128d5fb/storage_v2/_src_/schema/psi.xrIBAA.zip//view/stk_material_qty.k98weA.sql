create definer = root@localhost view stk_material_qty as
select `m`.`id`                                           AS `id`,
       max(`m`.`unit_id`)                                 AS `unit_id`,
       sum(((`i`.`qty` * `iu`.`factor`) / `mu`.`factor`)) AS `qty`
from (((`psi`.`bas_material` `m` join `psi`.`stk_inventory` `i` on (((`m`.`id` = `i`.`material_id`) and (`i`.`is_closed` = 0)))) join `psi`.`bas_unit` `mu` on ((`m`.`unit_id` = `mu`.`id`)))
         join `psi`.`bas_unit` `iu` on ((`i`.`unit_id` = `iu`.`id`)))
group by `m`.`id`;

-- comment on column stk_material_qty.id not supported: ID

-- comment on column stk_material_qty.unit_id not supported: 计量单位

