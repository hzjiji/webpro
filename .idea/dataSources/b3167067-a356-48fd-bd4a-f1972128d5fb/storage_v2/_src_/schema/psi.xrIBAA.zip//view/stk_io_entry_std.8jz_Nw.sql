create definer = root@localhost view stk_io_entry_std as
select `e`.`id`                                                AS `id`,
       `e`.`mid`                                               AS `mid`,
       `e`.`material_id`                                       AS `material_id`,
       `e`.`warehouse_id`                                      AS `warehouse_id`,
       `e`.`batch_no`                                          AS `batch_no`,
       `m`.`unit_id`                                           AS `unit_id`,
       `e`.`stock_io_direction`                                AS `stock_io_direction`,
       round(((`e`.`qty` * `eu`.`factor`) / `mu`.`factor`), 3) AS `qty`,
       `e`.`cost`                                              AS `cost`
from (((`psi`.`stk_io_entry` `e` join `psi`.`bas_unit` `eu` on ((`e`.`unit_id` = `eu`.`id`))) join `psi`.`bas_material` `m` on ((`e`.`material_id` = `m`.`id`)))
         join `psi`.`bas_unit` `mu` on ((`m`.`unit_id` = `mu`.`id`)));

-- comment on column stk_io_entry_std.id not supported: ID

-- comment on column stk_io_entry_std.mid not supported: 主表

-- comment on column stk_io_entry_std.material_id not supported: 物料

-- comment on column stk_io_entry_std.warehouse_id not supported: 仓库

-- comment on column stk_io_entry_std.batch_no not supported: 批次号

-- comment on column stk_io_entry_std.unit_id not supported: 计量单位

-- comment on column stk_io_entry_std.stock_io_direction not supported: 出入方向

-- comment on column stk_io_entry_std.cost not supported: 成本

