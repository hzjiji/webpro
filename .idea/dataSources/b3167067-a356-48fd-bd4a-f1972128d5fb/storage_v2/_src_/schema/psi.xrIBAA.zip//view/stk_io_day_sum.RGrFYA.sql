create definer = root@localhost view stk_io_day_sum as
select max(`psi`.`e`.`id`)                                                                  AS `id`,
       `b`.`bill_date`                                                                      AS `bill_date`,
       `psi`.`e`.`warehouse_id`                                                             AS `warehouse_id`,
       `psi`.`e`.`material_id`                                                              AS `material_id`,
       `psi`.`e`.`batch_no`                                                                 AS `batch_no`,
       `psi`.`e`.`unit_id`                                                                  AS `unit_id`,
       sum((case `psi`.`e`.`stock_io_direction` when '1' then `psi`.`e`.`qty` else 0 end))  AS `in_qty`,
       sum((case `psi`.`e`.`stock_io_direction` when '1' then `psi`.`e`.`cost` else 0 end)) AS `in_cost`,
       sum((case `psi`.`e`.`stock_io_direction` when '2' then `psi`.`e`.`qty` else 0 end))  AS `out_qty`,
       sum((case `psi`.`e`.`stock_io_direction` when '2' then `psi`.`e`.`cost` else 0 end)) AS `out_cost`
from (`psi`.`stk_io` `b`
         join `psi`.`stk_io_entry_std` `e` on ((`b`.`id` = `psi`.`e`.`mid`)))
where ((`b`.`is_effective` = 1) and (`b`.`is_voided` = 0))
group by `b`.`bill_date`, `psi`.`e`.`warehouse_id`, `psi`.`e`.`material_id`, `psi`.`e`.`batch_no`, `psi`.`e`.`unit_id`;

-- comment on column stk_io_day_sum.id not supported: ID

-- comment on column stk_io_day_sum.bill_date not supported: 单据日期

-- comment on column stk_io_day_sum.warehouse_id not supported: 仓库

-- comment on column stk_io_day_sum.material_id not supported: 物料

-- comment on column stk_io_day_sum.batch_no not supported: 批次号

-- comment on column stk_io_day_sum.unit_id not supported: 计量单位

