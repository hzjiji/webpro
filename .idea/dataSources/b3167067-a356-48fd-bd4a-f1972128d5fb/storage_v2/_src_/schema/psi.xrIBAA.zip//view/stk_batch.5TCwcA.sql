create definer = root@localhost view stk_batch as
select distinct `psi`.`stk_inventory`.`batch_no` AS `batch_no`
from `psi`.`stk_inventory`
where (`psi`.`stk_inventory`.`is_closed` = 0);

-- comment on column stk_batch.batch_no not supported: 批号

