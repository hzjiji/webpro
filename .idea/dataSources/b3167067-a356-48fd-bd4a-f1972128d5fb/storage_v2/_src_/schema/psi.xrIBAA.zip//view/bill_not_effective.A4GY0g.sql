create definer = root@localhost view bill_not_effective as
select 1 AS `seq`, '销售报价' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`sal_quot` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 2 AS `seq`, '销售订单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`sal_order` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 3 AS `seq`, '出库单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`stk_io` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0) and (`b`.`stock_io_type` like '2%'))
union
select 4 AS `seq`, '应收单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_receivable` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 5 AS `seq`, '销售退货退款申请' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_receipt_req` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 6 AS `seq`, '收款单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_receipt` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 7 AS `seq`, '应收核销' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_receivable_check` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 8 AS `seq`, '销售发票登记' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_sal_invoice` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 9 AS `seq`, '采购申请' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`pur_req` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 10 AS `seq`, '采购询价' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`pur_inquiry` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 11 AS `seq`, '供应报价' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`pur_quot` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 12 AS `seq`, '采购比价' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`pur_compare` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 13 AS `seq`, '采购订单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`pur_order` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 14 AS `seq`, '入库单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`stk_io` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0) and (`b`.`stock_io_type` like '1%'))
union
select 15 AS `seq`, '应付单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_payable` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 16 AS `seq`, '付款申请' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_payment_req` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 17 AS `seq`, '付款单' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_payment` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 18 AS `seq`, '应付核销' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_payable_check` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 19 AS `seq`, '采购发票登记' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`fin_pur_invoice` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0))
union
select 20 AS `seq`, '库存调拨、成本调整' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`stk_io` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0) and (`b`.`stock_io_type` > '2'))
union
select 21 AS `seq`, '库存盘点' AS `name`, `b`.`id` AS `id`, `b`.`bill_no` AS `bill_no`, `b`.`bill_date` AS `bill_date`
from `psi`.`stk_check` `b`
where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`is_effective` = 0));

