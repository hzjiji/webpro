create definer = root@localhost view home_purchase as
select '订单'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`pur_order`.`amt`), 0) AS `amt`
        from `psi`.`pur_order`
        where ((`psi`.`pur_order`.`is_effective` = 1) and (`psi`.`pur_order`.`is_voided` = 0) and
               (`psi`.`pur_order`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                                AS `count`,
                                                                                                  ifnull(sum(`psi`.`pur_order`.`amt`), 0) AS `amt`
                                                                                           from `psi`.`pur_order`
                                                                                           where ((`psi`.`pur_order`.`is_effective` = 1) and
                                                                                                  (`psi`.`pur_order`.`is_voided` = 0) and
                                                                                                  (yearweek(`psi`.`pur_order`.`effective_time`, 1) =
                                                                                                   yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`pur_order`.`amt`), 0) AS `amt`
               from `psi`.`pur_order`
               where ((`psi`.`pur_order`.`is_effective` = 1) and (`psi`.`pur_order`.`is_voided` = 0) and
                      (year(`psi`.`pur_order`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`pur_order`.`effective_time`) = month(sysdate())))) `m`)
union
select '入库'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`stk_io`.`cost`), 0) AS `amt`
        from `psi`.`stk_io`
        where ((`psi`.`stk_io`.`is_effective` = 1) and (`psi`.`stk_io`.`is_voided` = 0) and
               (`psi`.`stk_io`.`stock_io_type` like '1%') and
               (`psi`.`stk_io`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                              AS `count`,
                                                                                               ifnull(sum(`psi`.`stk_io`.`cost`), 0) AS `amt`
                                                                                        from `psi`.`stk_io`
                                                                                        where ((`psi`.`stk_io`.`is_effective` = 1) and
                                                                                               (`psi`.`stk_io`.`is_voided` = 0) and
                                                                                               (`psi`.`stk_io`.`stock_io_type` like '1%') and
                                                                                               (yearweek(`psi`.`stk_io`.`effective_time`, 1) =
                                                                                                yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`stk_io`.`cost`), 0) AS `amt`
               from `psi`.`stk_io`
               where ((`psi`.`stk_io`.`is_effective` = 1) and (`psi`.`stk_io`.`is_voided` = 0) and
                      (`psi`.`stk_io`.`stock_io_type` like '1%') and
                      (year(`psi`.`stk_io`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`stk_io`.`effective_time`) = month(sysdate())))) `m`)
union
select '应付'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`fin_payable`.`amt`), 0) AS `amt`
        from `psi`.`fin_payable`
        where ((`psi`.`fin_payable`.`is_effective` = 1) and (`psi`.`fin_payable`.`is_voided` = 0) and
               (`psi`.`fin_payable`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                                  AS `count`,
                                                                                                    ifnull(sum(`psi`.`fin_payable`.`amt`), 0) AS `amt`
                                                                                             from `psi`.`fin_payable`
                                                                                             where ((`psi`.`fin_payable`.`is_effective` = 1) and
                                                                                                    (`psi`.`fin_payable`.`is_voided` = 0) and
                                                                                                    (yearweek(`psi`.`fin_payable`.`effective_time`, 1) =
                                                                                                     yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`fin_payable`.`amt`), 0) AS `amt`
               from `psi`.`fin_payable`
               where ((`psi`.`fin_payable`.`is_effective` = 1) and (`psi`.`fin_payable`.`is_voided` = 0) and
                      (year(`psi`.`fin_payable`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`fin_payable`.`effective_time`) = month(sysdate())))) `m`)
union
select '付款'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`fin_payment`.`amt`), 0) AS `amt`
        from `psi`.`fin_payment`
        where ((`psi`.`fin_payment`.`is_effective` = 1) and (`psi`.`fin_payment`.`is_voided` = 0) and
               (`psi`.`fin_payment`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                                  AS `count`,
                                                                                                    ifnull(sum(`psi`.`fin_payment`.`amt`), 0) AS `amt`
                                                                                             from `psi`.`fin_payment`
                                                                                             where ((`psi`.`fin_payment`.`is_effective` = 1) and
                                                                                                    (`psi`.`fin_payment`.`is_voided` = 0) and
                                                                                                    (yearweek(`psi`.`fin_payment`.`effective_time`, 1) =
                                                                                                     yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`fin_payment`.`amt`), 0) AS `amt`
               from `psi`.`fin_payment`
               where ((`psi`.`fin_payment`.`is_effective` = 1) and (`psi`.`fin_payment`.`is_voided` = 0) and
                      (year(`psi`.`fin_payment`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`fin_payment`.`effective_time`) = month(sysdate())))) `m`);

