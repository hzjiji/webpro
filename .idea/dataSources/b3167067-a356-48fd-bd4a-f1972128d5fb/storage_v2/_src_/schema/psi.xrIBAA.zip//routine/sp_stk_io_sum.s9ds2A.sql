create
    definer = root@localhost procedure sp_stk_io_sum(IN p_year smallint, IN p_month tinyint)
BEGIN
	DECLARE n_year SMALLINT;
	DECLARE n_month TINYINT;

	DROP TABLE IF EXISTS `tmp`;
	CREATE TEMPORARY TABLE tmp(
		material_id VARCHAR(36),
		batch_no VARCHAR(100),
		warehouse_id VARCHAR(36),
		unit_id VARCHAR(36),
		in_qty DECIMAL(18,6) DEFAULT 0,
		in_cost DECIMAL(18,2) DEFAULT 0,
		out_qty DECIMAL(18,6) DEFAULT 0,
		out_cost DECIMAL(18,2) DEFAULT 0
	);
	
	#初始发生数:上月汇总已生成本月的期初数
	UPDATE stk_io_sum s 
		 SET s.in_qty = 0, s.in_cost = 0, s.out_qty = 0, s.out_cost = 0
	 WHERE s.`year` = p_year
	   AND s.`month` = p_month;
	
	#发生数
	INSERT INTO tmp(material_id, batch_no, warehouse_id, unit_id, in_qty, in_cost, out_qty, out_cost)
		SELECT e.material_id, e.batch_no, e.warehouse_id, e.unit_id, 
           SUM(CASE e.stock_io_direction WHEN '1' THEN e.qty ELSE 0 END) in_qty,
           SUM(CASE e.stock_io_direction WHEN '1' THEN e.cost ELSE 0 END) in_cost,
           SUM(CASE e.stock_io_direction WHEN '2' THEN e.qty ELSE 0 END) out_qty,
           SUM(CASE e.stock_io_direction WHEN '2' THEN e.cost ELSE 0 END) out_cost
			FROM stk_io b
		 INNER JOIN stk_io_entry_std e
			  ON b.id = e.mid
		 WHERE b.is_effective = 1 
			 AND b.is_voided = 0
			 AND b.bill_date BETWEEN fn_first_day_of_ym(p_year,p_month) AND fn_last_day_of_ym(p_year,p_month)
		 GROUP BY e.material_id, e.batch_no, e.warehouse_id, e.unit_id;

	UPDATE stk_io_sum s
	 INNER JOIN tmp t
			ON s.material_id = t.material_id
		 AND s.batch_no = t.batch_no
		 AND s.warehouse_id = t.warehouse_id
		 AND s.unit_id = t.unit_id
		 SET s.in_qty = t.in_qty, s.in_cost = t.in_cost, s.out_qty = t.out_qty, s.out_cost = t.out_cost
	 WHERE s.`year` = p_year
		 AND s.`month` = p_month;

	#本月新增
	INSERT INTO stk_io_sum(id, `year`, `month`, material_id, batch_no, warehouse_id, unit_id, begin_qty, begin_cost, in_qty, in_cost, out_qty, out_cost)
		SELECT MD5(UUID()), p_year, p_month, t.material_id, t.batch_no, t.warehouse_id, t.unit_id, 0, 0, t.in_qty, t.in_cost, t.out_qty, t.out_cost
			FROM tmp t
			LEFT JOIN stk_io_sum s
				ON t.material_id = s.material_id
		   AND t.batch_no = s.batch_no
		   AND t.warehouse_id = s.warehouse_id
		   AND t.unit_id = s.unit_id
			 AND s.`year` = p_year
			 AND s.`month` = p_month
		 WHERE s.id IS NULL;

  #期末结存
	UPDATE stk_io_sum s
		 SET s.bal_qty = IFNULL(s.begin_qty, 0) + IFNULL(s.in_qty, 0) - IFNULL(s.out_qty, 0),
		     s.bal_cost = IFNULL(s.begin_cost, 0) + IFNULL(s.in_cost, 0) - IFNULL(s.out_cost, 0)
	 WHERE s.`year` = p_year
		 AND s.`month` = p_month;

	#结转下月
	IF p_month < 12 THEN
		SET @n_year = p_year, @n_month = p_month + 1;
	ELSE
		SET @n_year = p_year + 1, @n_month = 1;
	END IF;

	DELETE FROM stk_io_sum
	 WHERE `year` = @n_year
		 AND `month` = @n_month;

	INSERT INTO stk_io_sum(id, `year`, `month`, material_id, batch_no, warehouse_id, unit_id, begin_qty, begin_cost, in_qty, in_cost, out_qty, out_cost, bal_qty, bal_cost)
		SELECT MD5(UUID()), @n_year, @n_month, s.material_id, s.batch_no, s.warehouse_id, s.unit_id, s.bal_qty, s.bal_cost, 0, 0, 0, 0, 0, 0
			FROM stk_io_sum s
		 WHERE s.bal_qty != 0
       AND s.bal_cost != 0
			 AND s.`year` = p_year
			 AND s.`month` = p_month;
END;

