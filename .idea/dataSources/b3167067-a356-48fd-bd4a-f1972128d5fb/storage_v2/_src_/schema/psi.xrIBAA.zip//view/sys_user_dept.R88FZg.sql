create definer = root@localhost view sys_user_dept as
select `ud`.`dep_id` AS `dept_id`, `u`.`username` AS `username`
from (`psi`.`sys_user` `u`
         join `psi`.`sys_user_depart` `ud` on ((`u`.`id` = `ud`.`user_id`)));

-- comment on column sys_user_dept.dept_id not supported: 部门id

-- comment on column sys_user_dept.username not supported: 登录账号

