create definer = root@localhost view home_doing_bill as
select `t`.`name`            AS `name`,
       ifnull(`t`.`edit`, 0) AS `edit`,
       ifnull(`t`.`appr`, 0) AS `appr`,
       ifnull(`t`.`exec`, 0) AS `exec`
from (select '销售报价' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`sal_quot` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '销售订单' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`sal_order` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '出库单' AS                                                    `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`stk_io` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`stock_io_type` like '2%'))
      union
      select '应收单' AS                                                    `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`fin_receivable` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '收款单' AS                                                    `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`fin_receipt` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '销售发票' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`fin_sal_invoice` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '采购申请' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`pur_req` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '采购询价' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`pur_inquiry` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '供应报价' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`pur_quot` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '采购比价' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`pur_compare` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '采购订单' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`pur_order` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '入库单' AS                                                    `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`stk_io` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0) and (`b`.`stock_io_type` like '1%'))
      union
      select '应付单' AS                                                    `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`fin_payable` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '付款申请' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`fin_payment_req` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '付款单' AS                                                    `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`fin_payment` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '采购发票' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`fin_pur_invoice` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))
      union
      select '库存盘点' AS                                                   `name`,
             sum((case `b`.`bill_stage` when '12' then 1 else 0 end)) AS `edit`,
             sum((case
                      when ((`b`.`bill_stage` in ('14', '22')) and (`b`.`is_effective` = 0)) then 1
                      else 0 end)) AS                                    `appr`,
             sum((case
                      when ((`b`.`bill_stage` in ('24', '32')) and (`b`.`is_effective` = 1)) then 1
                      else 0 end)) AS                                    `exec`
      from `psi`.`stk_check` `b`
      where ((`b`.`is_closed` = 0) and (`b`.`is_voided` = 0))) `t`;

