create definer = root@localhost view home_sale as
select '订单'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`sal_order`.`amt`), 0) AS `amt`
        from `psi`.`sal_order`
        where ((`psi`.`sal_order`.`is_effective` = 1) and (`psi`.`sal_order`.`is_voided` = 0) and
               (`psi`.`sal_order`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                                AS `count`,
                                                                                                  ifnull(sum(`psi`.`sal_order`.`amt`), 0) AS `amt`
                                                                                           from `psi`.`sal_order`
                                                                                           where ((`psi`.`sal_order`.`is_effective` = 1) and
                                                                                                  (`psi`.`sal_order`.`is_voided` = 0) and
                                                                                                  (yearweek(`psi`.`sal_order`.`effective_time`, 1) =
                                                                                                   yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`sal_order`.`amt`), 0) AS `amt`
               from `psi`.`sal_order`
               where ((`psi`.`sal_order`.`is_effective` = 1) and (`psi`.`sal_order`.`is_voided` = 0) and
                      (year(`psi`.`sal_order`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`sal_order`.`effective_time`) = month(sysdate())))) `m`)
union
select '出库'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`stk_io`.`cost`), 0) AS `amt`
        from `psi`.`stk_io`
        where ((`psi`.`stk_io`.`is_effective` = 1) and (`psi`.`stk_io`.`is_voided` = 0) and
               (`psi`.`stk_io`.`stock_io_type` like '2%') and
               (`psi`.`stk_io`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                              AS `count`,
                                                                                               ifnull(sum(`psi`.`stk_io`.`cost`), 0) AS `amt`
                                                                                        from `psi`.`stk_io`
                                                                                        where ((`psi`.`stk_io`.`is_effective` = 1) and
                                                                                               (`psi`.`stk_io`.`is_voided` = 0) and
                                                                                               (`psi`.`stk_io`.`stock_io_type` like '2%') and
                                                                                               (yearweek(`psi`.`stk_io`.`effective_time`, 1) =
                                                                                                yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`stk_io`.`cost`), 0) AS `amt`
               from `psi`.`stk_io`
               where ((`psi`.`stk_io`.`is_effective` = 1) and (`psi`.`stk_io`.`is_voided` = 0) and
                      (`psi`.`stk_io`.`stock_io_type` like '2%') and
                      (year(`psi`.`stk_io`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`stk_io`.`effective_time`) = month(sysdate())))) `m`)
union
select '应收'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`fin_receivable`.`amt`), 0) AS `amt`
        from `psi`.`fin_receivable`
        where ((`psi`.`fin_receivable`.`is_effective` = 1) and (`psi`.`fin_receivable`.`is_voided` = 0) and
               (`psi`.`fin_receivable`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                                     AS `count`,
                                                                                                       ifnull(sum(`psi`.`fin_receivable`.`amt`), 0) AS `amt`
                                                                                                from `psi`.`fin_receivable`
                                                                                                where ((`psi`.`fin_receivable`.`is_effective` = 1) and
                                                                                                       (`psi`.`fin_receivable`.`is_voided` = 0) and
                                                                                                       (yearweek(`psi`.`fin_receivable`.`effective_time`, 1) =
                                                                                                        yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`fin_receivable`.`amt`), 0) AS `amt`
               from `psi`.`fin_receivable`
               where ((`psi`.`fin_receivable`.`is_effective` = 1) and (`psi`.`fin_receivable`.`is_voided` = 0) and
                      (year(`psi`.`fin_receivable`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`fin_receivable`.`effective_time`) = month(sysdate())))) `m`)
union
select '收款'        AS `label`,
       `t`.`count` AS `t_count`,
       `t`.`amt`   AS `t_amt`,
       `w`.`count` AS `w_count`,
       `w`.`amt`   AS `w_amt`,
       `m`.`count` AS `m_count`,
       `m`.`amt`   AS `m_amt`
from (((select count(1) AS `count`, ifnull(sum(`psi`.`fin_receipt`.`amt`), 0) AS `amt`
        from `psi`.`fin_receipt`
        where ((`psi`.`fin_receipt`.`is_effective` = 1) and (`psi`.`fin_receipt`.`is_voided` = 0) and
               (`psi`.`fin_receipt`.`effective_time` >= cast(sysdate() as date)))) `t` join (select count(1)                                  AS `count`,
                                                                                                    ifnull(sum(`psi`.`fin_receipt`.`amt`), 0) AS `amt`
                                                                                             from `psi`.`fin_receipt`
                                                                                             where ((`psi`.`fin_receipt`.`is_effective` = 1) and
                                                                                                    (`psi`.`fin_receipt`.`is_voided` = 0) and
                                                                                                    (yearweek(`psi`.`fin_receipt`.`effective_time`, 1) =
                                                                                                     yearweek(sysdate(), 1)))) `w`)
         join (select count(1) AS `count`, ifnull(sum(`psi`.`fin_receipt`.`amt`), 0) AS `amt`
               from `psi`.`fin_receipt`
               where ((`psi`.`fin_receipt`.`is_effective` = 1) and (`psi`.`fin_receipt`.`is_voided` = 0) and
                      (year(`psi`.`fin_receipt`.`effective_time`) = year(sysdate())) and
                      (month(`psi`.`fin_receipt`.`effective_time`) = month(sysdate())))) `m`);

