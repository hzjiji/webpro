create
    definer = root@localhost procedure sp_fin_payable_sum(IN p_year smallint, IN p_month tinyint)
BEGIN
	DECLARE n_year SMALLINT;
	DECLARE n_month TINYINT;

	DROP TABLE IF EXISTS `tmp`;
	CREATE TEMPORARY TABLE tmp(
		supplier_id VARCHAR(36),
		amt DECIMAL(18,2) DEFAULT 0
	);
	
	#初始金额:上月汇总已生成本月的期初数据
	UPDATE fin_payable_sum b 
		 SET b.debit_amt = 0, b.credit_amt = 0
	 WHERE b.`year` = p_year
	   AND b.`month` = p_month;
	
	#贷方金额
	INSERT INTO tmp(supplier_id, amt)
		SELECT p.supplier_id, SUM(p.amt) amt
			FROM fin_payable p
		 WHERE p.is_effective = 1 
			 AND p.is_voided = 0
			 AND p.bill_date BETWEEN fn_first_day_of_ym(p_year,p_month) AND fn_last_day_of_ym(p_year,p_month)
		 GROUP BY p.supplier_id;

	UPDATE fin_payable_sum b
	 INNER JOIN tmp a
			ON b.supplier_id = a.supplier_id
		 AND b.`year` = p_year
		 AND b.`month` = p_month
		 SET b.credit_amt = a.amt;

	#本月新增
	INSERT INTO fin_payable_sum(id, `year`, `month`, supplier_id, begin_credit_bal, debit_amt, credit_amt)
		SELECT MD5(UUID()), p_year, p_month, a.supplier_id, 0, 0, a.amt
			FROM tmp a
			LEFT JOIN fin_payable_sum b
				ON a.supplier_id = b.supplier_id
			 AND b.`year` = p_year
			 AND b.`month` = p_month
		 WHERE b.supplier_id IS NULL;

	SELECT IFNULL(SUM(amt), 0) INTO @credit_amt FROM tmp;

	DELETE FROM tmp;
	
	#借方金额
	INSERT INTO tmp(supplier_id, amt)
		SELECT p.supplier_id, SUM(p.amt) amt
			FROM fin_payment p
		 WHERE p.is_effective = 1 
			 AND p.is_voided = 0
			 AND p.bill_date BETWEEN fn_first_day_of_ym(p_year,p_month) AND fn_last_day_of_ym(p_year,p_month)
		 GROUP BY p.supplier_id;

	UPDATE fin_payable_sum b
	 INNER JOIN tmp a
			ON b.supplier_id = a.supplier_id
		 AND b.`year` = p_year
		 AND b.`month` = p_month
		 SET b.debit_amt = a.amt;

	#本月新增
	INSERT INTO fin_payable_sum(id, `year`, `month`, supplier_id, begin_credit_bal, debit_amt, credit_amt)
		SELECT MD5(UUID()), p_year, p_month, a.supplier_id, 0, a.amt, 0
			FROM tmp a
			LEFT JOIN fin_payable_sum b
				ON a.supplier_id = b.supplier_id
			 AND b.`year` = p_year
			 AND b.`month` = p_month
		 WHERE b.supplier_id IS NULL;	

	SELECT IFNULL(SUM(amt), 0) INTO @debit_amt FROM tmp;

	#金额合计
	SELECT COUNT(b.id) 
		INTO @num
		FROM fin_payable_sum b
	 WHERE b.`year` = p_year
		 AND b.`month` = p_month
		 AND b.supplier_id IS NULL;

	IF @num = 0 THEN
		INSERT INTO fin_payable_sum(id, `year`, `month`, supplier_id, begin_credit_bal, debit_amt, credit_amt)
			SELECT MD5(UUID()), p_year, p_month, NULL, IFNULL(SUM(b.begin_credit_bal), 0), IFNULL(SUM(b.debit_amt), 0), IFNULL(SUM(b.credit_amt), 0)
				FROM fin_payable_sum b
			 WHERE b.`year` = p_year
				 AND b.`month` = p_month
				 AND b.supplier_id IS NOT NULL;
	ELSE
		UPDATE fin_payable_sum b 
			 SET b.debit_amt = @debit_amt, b.credit_amt = @credit_amt
		 WHERE b.`year` = p_year
			 AND b.`month` = p_month
			 AND b.supplier_id IS NULL;
	END IF;

  #期末余额
	UPDATE fin_payable_sum b 
		 SET b.credit_bal = IFNULL(b.begin_credit_bal,0) - IFNULL(b.debit_amt,0) + IFNULL(b.credit_amt, 0)
	 WHERE b.`year` = p_year
		 AND b.`month` = p_month;

	#结转下月
	IF p_month < 12 THEN
		SET @n_year = p_year, @n_month = p_month + 1;
	ELSE
		SET @n_year = p_year + 1, @n_month = 1;
	END IF;

	DELETE FROM fin_payable_sum
	 WHERE `year` = @n_year
		 AND `month` = @n_month;

	INSERT INTO fin_payable_sum(id, `year`, `month`, supplier_id, begin_credit_bal, debit_amt, credit_amt)
		SELECT MD5(UUID()), @n_year, @n_month, IFNULL(b.supplier_id, c.id), b.credit_bal, 0, 0
			FROM fin_payable_sum b
			LEFT JOIN bas_supplier c
				ON b.supplier_id = c.id
			 AND c.is_enabled = 1	
		 WHERE b.credit_bal != 0
			 AND b.`year` = p_year
			 AND b.`month` = p_month;
END;

