create
    definer = root@localhost procedure ex_while()
BEGIN
  DECLARE i INT DEFAULT 50;
  DECLARE total INT DEFAULT 0;
  
  WHILE i <= 100 DO
    SET total = total + i;
    SET i = i + 1;
  END WHILE;

  SELECT total AS sum_of_numbers;
END;

