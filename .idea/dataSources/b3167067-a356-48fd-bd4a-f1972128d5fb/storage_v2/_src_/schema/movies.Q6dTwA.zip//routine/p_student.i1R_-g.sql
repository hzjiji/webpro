create
    definer = root@localhost procedure p_student()
BEGIN
    SELECT sno, sname, birthday, tel
    FROM Student
    WHERE tel LIKE '135%';
END;

